import React, { useState, useEffect } from "react";
import "./Game.css";

// Import town components
import Jakarta from "./towns/Jakarta";
import Padang from "./towns/Padang";
import Papua from "./towns/Papua";
import Magelang from "./towns/Magelang";
import Home from "./towns/Home";

function Game() {
  const CHARACTER_SIZE = 150;
  const [position, setPosition] = useState({ x: 50, y: 50 });
  const [direction, setDirection] = useState("right");
  const [characterImage, setCharacterImage] = useState("revlog-idle");
  const [currentTown, setCurrentTown] = useState(null);
  const [showExploreButton, setShowExploreButton] = useState(false);
  const [nearSign, setNearSign] = useState(null);
  const [showSignDetails, setShowSignDetails] = useState(false);

  // Character stats
  const [stats, setStats] = useState(() => {
    const savedStats = localStorage.getItem("gameStats");
    return savedStats
      ? JSON.parse(savedStats)
      : {
          happiness: 100,
          hunger: 100,
          sleep: 100,
          hygiene: 100,
          gold: 0,
        };
  });

  // Get selected character from localStorage
  const selectedCharacter = localStorage.getItem("selectedCharacter") || "revlog";

  // Define town coordinates with percentage values
  const towns = {
    home: { x: 14, y: 21, name: "Home" },
    jakarta: { x: 12, y: 57, name: "Jakarta" },
    padang: { x: 45, y: 84, name: "Padang" },
    papua: { x: 86, y: 86, name: "Papua" },
    magelang: { x: 81, y: 28, name: "Magelang" },
  };

  // Check if character is near a town
  const checkNearTown = (x, y) => {
    const TOWN_DETECTION_RADIUS = 5;
    for (const [townId, town] of Object.entries(towns)) {
      const distance = Math.sqrt(
        Math.pow(x - town.x, 2) + Math.pow(y - town.y, 2)
      );
      if (distance < TOWN_DETECTION_RADIUS) {
        setShowExploreButton(true);
        return townId;
      }
    }
    setShowExploreButton(false);
    return null;
  };

  // Function to handle character movement
  const moveCharacter = (moveDirection) => {
    setPosition((prev) => {
      let { x, y } = prev;
      const step = 1;
      switch (moveDirection) {
        case "left":
          x = Math.max(x - step, 0);
          setDirection("left");
          setCharacterImage(`${selectedCharacter}-left`);
          break;
        case "right":
          x = Math.min(x + step, 100);
          setDirection("right");
          setCharacterImage(`${selectedCharacter}-right`);
          break;
        case "up":
          y = Math.max(y - step, 0);
          setDirection("up");
          setCharacterImage(`${selectedCharacter}-left`);
          break;
        case "down":
          y = Math.min(y + step, 100);
          setDirection("down");
          setCharacterImage(`${selectedCharacter}-right`);
          break;
        default:
          return prev;
      }
      checkNearTown(x, y);
      return { x, y };
    });
  };

  // Handle keyboard controls
  useEffect(() => {
    const handleKeyDown = (e) => {
      switch (e.key) {
        case "ArrowLeft":
        case "a":
          moveCharacter("left");
          break;
        case "ArrowRight":
        case "d":
          moveCharacter("right");
          break;
        case "ArrowUp":
        case "w":
          moveCharacter("up");
          break;
        case "ArrowDown":
        case "s":
          moveCharacter("down");
          break;
      }
    };

    const handleKeyUp = () => {
      setCharacterImage(`${selectedCharacter}-idle`);
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [selectedCharacter]);

  // Function to explore town
  const exploreTown = () => {
    const townId = checkNearTown(position.x, position.y);
    if (townId) {
      setCurrentTown(townId);
    }
  };

  // Function to return to main map
  const returnToMainMap = () => {
    setCurrentTown(null);
  };

  // Function to update specific stats
  const updateSpecificStats = (statUpdates) => {
    setStats((prevStats) => ({
      ...prevStats,
      ...statUpdates,
    }));
  };

  // Render town component if in a town
  if (currentTown) {
    const TownComponent = {
      home: Home,
      jakarta: Jakarta,
      padang: Padang,
      papua: Papua,
      magelang: Magelang,
    }[currentTown];

    return (
      <div className="town-container">
        <TownComponent
          onReturn={returnToMainMap}
          stats={stats}
          updateStats={updateSpecificStats}
        />
      </div>
    );
  }

  return (
    <div
      className="game-container"
      style={{
        backgroundImage: "url('/Picture/map-utama.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        width: "100vw",
        height: "100vh",
        position: "relative",
      }}
    >
      {/* Character */}
      <div
        style={{
          position: "absolute",
          left: `${position.x}%`,
          top: `${position.y}%`,
          width: `${CHARACTER_SIZE}px`,
          height: `${CHARACTER_SIZE}px`,
          backgroundImage: `url('/Picture/${characterImage}.png')`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          zIndex: 100,
          transform: "translate(-50%, -50%)",
        }}
      />

      {/* Town Markers */}
      {Object.entries(towns).map(([townId, town]) => (
        <div
          key={townId}
          style={{
            position: "absolute",
            left: `${town.x}%`,
            top: `${town.y}%`,
            transform: "translate(-50%, -50%)",
            width: "40px",
            height: "40px",
            backgroundImage: "url('/Picture/town-marker.png')",
            backgroundSize: "contain",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center",
            zIndex: 90,
          }}
        />
      ))}

      {/* Explore Button */}
      {showExploreButton && (
        <button
          className="explore-button"
          onClick={exploreTown}
          style={{
            position: "absolute",
            left: `${position.x}%`,
            top: `${position.y - 10}%`,
            transform: "translate(-50%, -50%)",
            zIndex: 1000,
          }}
        >
          Explore
        </button>
      )}

      {/* Coordinate Display */}
      <div
        style={{
          position: "fixed",
          top: "10px",
          left: "10px",
          backgroundColor: "rgba(0, 0, 0, 0.8)",
          color: "white",
          padding: "8px 15px",
          borderRadius: "5px",
          border: "2px solid #ffd700",
          fontSize: "14px",
          zIndex: 1000,
          fontFamily: "monospace",
        }}
      >
        X: {Math.round(position.x)}% | Y: {Math.round(position.y)}%
      </div>
    </div>
  );
}

export default Game; 